## How to run project

The Laravel backend service enables user authentication with jwt. It allows authenticated user to Create, read and update task. The following steps describes how to start the application
The database is an instance of a Sqlite DB. The eventor.sqlite folder is saved at the root folder of the application. Please edit the .env folder to make sure the DB_DATABASE points to the absolute url of the sqlite file.

- Start application by running the command "php artisan serve" without quotes in the command line
- Proceed to download the frontend application [here](https://github.com/Juboy).
